<?php

namespace suver\behavior\upload\models;

use Yii;

/**
 *
 *
 * Interface UploadsInterface
 * @package suver\behavior\upload\models
 */
interface UploadsInterface
{
    public function getName();
    public function getExtension();
}
