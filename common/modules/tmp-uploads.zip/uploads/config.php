<?php
return [
    'components' => [
        // список конфигураций компонентов
    ],
    'params' => [
        'defaultAuthorPerPage' => 16,
        'defaultCatalogPerPage' => 50,
    ],
];
